﻿namespace MyLib1NS;   
static public class MyLib1 {
  static public void PrintString() {
    Console.WriteLine("PrintString from MyLib1 called...");
  }
}

