﻿namespace DemoNS;
class CompDemos {

  public static void Demo() {
    ComparableDemoNS.ComparableDemo.Demo();
    ComparisonDemoNS.ComparisonDemo.Demo(); // best in practice!
    ComparerDemoNS.ComparerDemo.Demo();
  }
}

