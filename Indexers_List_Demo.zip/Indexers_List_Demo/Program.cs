﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoNS {
  class Program {

    static void StringDemo() {
      string s = "hello";
      WriteLine(s[0]);
      WriteLine(s[3]);
      WriteLine();
    }




    static void PersonsDemo() {
      Person[] persArr = {
        new Person { PersonID = 10, IIN = "111111111111", LastName = "Smith", FirstName = "Sean" },
        new Person { PersonID = 5, IIN = "222222222222", LastName = "Karimov", FirstName = "Karim" },
        new Person { PersonID = 4, IIN = "333333333333", LastName = "Ivanov", FirstName = "Ivan" },
        new Person { PersonID = 20, IIN = "", LastName = "Borisov", FirstName = "Boris" },
        new Person { PersonID = 15, IIN = "555555555555", LastName = "Abramov", FirstName = "Abram" },
      };

      var persons = new Persons(persArr);
      Person person; long newId = 444; string newLastName = "Abaev", newFirstName = "Abai";
      Person newPerson = new Person { PersonID = newId, LastName = newLastName, FirstName = newFirstName };

      person = persons[5];
      Console.WriteLine($"{person}");
      persons[5] = newPerson;
      person = persons[newId];
      WriteLine($"{person}");

      //by students - indexer by IIN:
      //person = persons["444444444444"];
      //WriteLine($"{person}");
      //persons["444444444444"] = newPerson;
      //person = persons[newLastName];
      //WriteLine($"{person}");
    }



    static void MatrixDemo() {
      var m = new Matrix(100, 200);
      m[10, 20] = 200;
      WriteLine($"m[10, 20] = {m[10, 20]}");
    }



    static void Main(string[] args) {
      try {
        //Sentence.Demo();
        //StringDemo();
        //PersonsDemo();
        //MatrixDemo();

       ListDemo.Demo();

      } catch (Exception ex) {
        WriteLine(ex.Message);
      }
      ReadLine();
    }
  }
}
