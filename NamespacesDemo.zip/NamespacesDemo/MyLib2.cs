﻿namespace MyLib2NS;
static public class MyLib2 {
  static public void PrintString() {
    Console.WriteLine("PrintString from MyLib2 called...");
  }

}
