﻿global using static System.Console;

namespace InterfacesNS;
class Program {

  static void Main(string[] args) {
    try {
      InterfaceDemo.Demo();
      ExtendingDemo.Demo();
      ExplicitAndMultyDemo.Demo();
      ComparableDemo.Demo();
      IComparerNS.ComparerDemo.Demo();

      EnumeratorDemo.Demo();
    } catch (Exception ex) {
      WriteLine(ex.Message);
    }
    WriteLine("\nEnd . . .");
    ReadLine();
  }
}

