﻿using PropInfo = System.Reflection.PropertyInfo;
using Refl = System.Reflection;


namespace Namespaces;
class Aliasing {
  class Program {
    PropInfo p1;

    Refl.PropertyInfo p2;
  }
}
