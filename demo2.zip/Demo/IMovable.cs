﻿namespace InterfacesNS;
interface IMovable {
  void Move();
}

