﻿namespace StudentsNS;
public class Globals {
  public const string StudentFileName = @"C:\_0\students_10_000_000.txt";
  public const string Student1000SampleFileName = @"C:\_0\students_1_000_sample.txt";
  public const string GroupFileName = @"C:\_0\groups_1_000_000.txt";
}

