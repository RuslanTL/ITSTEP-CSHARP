﻿namespace DemoNS;
class StackDemos {

  public static void Demo() {
    StackForDoubles.Demo();
    StackForObjects.Demo();
    StackGenericDemo.Demo();
  }
}

